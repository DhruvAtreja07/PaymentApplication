import React, { useState, useEffect, useRef } from 'react';

interface PinInputProps {
  length?: number;
  onChange: (pin: string) => void;
  placeholder?: string;
  error?: string;
  onComplete?: (pin: string) => void;
  className?: string;
}

const PinInput: React.FC<PinInputProps> = ({
  length = 4,
  onChange,
  placeholder = '●',
  error,
  onComplete,
  className = '',
}) => {
  const [pin, setPin] = useState<string[]>(Array(length).fill(''));
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  
  useEffect(() => {
    // Initialize refs
    inputRefs.current = inputRefs.current.slice(0, length);
    
    // Focus the first input on mount
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, [length]);
  
  useEffect(() => {
    // Call onChange callback
    onChange(pin.join(''));
    
    // Call onComplete if all inputs are filled
    if (pin.every(digit => digit !== '') && onComplete) {
      onComplete(pin.join(''));
    }
  }, [pin, onChange, onComplete]);
  
  const handleChange = (index: number, value: string) => {
    // Only accept numbers
    if (!/^\d*$/.test(value)) return;
    
    // Update the pin state
    const newPin = [...pin];
    newPin[index] = value.slice(-1); // Only take the last character
    setPin(newPin);
    
    // Autofocus next input if current input is filled
    if (value && index < length - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  };
  
  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    // Handle backspace
    if (e.key === 'Backspace') {
      if (!pin[index] && index > 0) {
        // If current input is empty, focus previous input and clear its value
        const newPin = [...pin];
        newPin[index - 1] = '';
        setPin(newPin);
        inputRefs.current[index - 1]?.focus();
      }
    }
    
    // Handle left arrow
    if (e.key === 'ArrowLeft' && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
    
    // Handle right arrow
    if (e.key === 'ArrowRight' && index < length - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  };
  
  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const paste = e.clipboardData.getData('text');
    if (!/^\d*$/.test(paste)) return; // Only accept numbers
    
    const pasteDigits = paste.split('').slice(0, length);
    const newPin = [...pin];
    
    pasteDigits.forEach((digit, i) => {
      if (i < length) {
        newPin[i] = digit;
      }
    });
    
    setPin(newPin);
    
    // Focus the next empty input or the last one
    const nextEmptyIndex = newPin.findIndex(digit => digit === '');
    if (nextEmptyIndex >= 0) {
      inputRefs.current[nextEmptyIndex]?.focus();
    } else {
      inputRefs.current[length - 1]?.focus();
    }
  };
  
  return (
    <div className="w-full">
      <div className={`flex justify-center gap-2 ${className}`}>
        {Array.from({ length }).map((_, index) => (
          <input
            key={index}
            type="text"
            inputMode="numeric"
            pattern="\d*"
            maxLength={1}
            value={pin[index]}
            placeholder={placeholder}
            ref={el => inputRefs.current[index] = el}
            onChange={e => handleChange(index, e.target.value)}
            onKeyDown={e => handleKeyDown(index, e)}
            onPaste={handlePaste}
            className={`
              w-12 h-12 text-center rounded-lg border-2 text-xl font-bold
              focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-200
              ${error ? 'border-red-500' : 'border-gray-300'}
            `}
            autoComplete="off"
          />
        ))}
      </div>
      {error && <p className="mt-2 text-sm text-red-500 text-center">{error}</p>}
    </div>
  );
};

export default PinInput;