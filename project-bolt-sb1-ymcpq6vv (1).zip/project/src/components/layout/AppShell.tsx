import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, PieChart, History, User, Menu, X, MessageSquare, Bell, LogOut } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { useMessageStore } from '../../store/messageStore';
import { useRequestStore } from '../../store/requestStore';
import { useNotificationStore } from '../../store/notificationStore';
import Avatar from '../ui/Avatar';

interface AppShellProps {
  children: React.ReactNode;
}

const AppShell: React.FC<AppShellProps> = ({ children }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { currentUser, logout } = useAuthStore();
  const { getUnreadCount: getUnreadMessageCount } = useMessageStore();
  const { getPendingRequestsCount } = useRequestStore();
  const { getUnreadCount: getUnreadNotificationCount } = useNotificationStore();
  
  const navItems = [
    {
      icon: Home,
      label: 'Home',
      path: '/dashboard',
    },
    {
      icon: MessageSquare,
      label: 'Messages',
      path: '/messages',
      badge: getUnreadMessageCount(),
    },
    {
      icon: History,
      label: 'Transactions',
      path: '/transactions',
    },
    {
      icon: PieChart,
      label: 'Requests',
      path: '/requests',
      badge: getPendingRequestsCount(),
    },
    {
      icon: Bell,
      label: 'Notifications',
      path: '/notifications',
      badge: getUnreadNotificationCount(),
    },
    {
      icon: User,
      label: 'Profile',
      path: '/profile',
    },
  ];
  
  const handleNavigation = (path: string) => {
    navigate(path);
    setMobileMenuOpen(false);
  };
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  return (
    <div className="flex h-screen bg-gray-50">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r border-gray-200 bg-white">
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-blue-600">PayNest</h2>
        </div>
        
        <div className="flex flex-col justify-between h-full">
          <nav className="mt-6 px-2 space-y-1">
            {navItems.map((item) => (
              <button
                key={item.path}
                onClick={() => handleNavigation(item.path)}
                className={`
                  flex items-center px-4 py-3 text-sm font-medium rounded-lg
                  ${location.pathname === item.path
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-100'}
                `}
              >
                <item.icon className="mr-3 h-5 w-5" />
                <span>{item.label}</span>
                {item.badge > 0 && (
                  <span className="ml-auto bg-red-500 text-white text-xs font-bold py-1 px-2 rounded-full">
                    {item.badge}
                  </span>
                )}
              </button>
            ))}
          </nav>
          
          <div className="p-4 border-t border-gray-200">
            <div className="flex items-center">
              <Avatar
                src={currentUser?.profilePic}
                name={currentUser?.fullName}
                size="md"
              />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-700 truncate">
                  {currentUser?.fullName}
                </p>
                <p className="text-xs text-gray-500">@{currentUser?.username}</p>
              </div>
              <button
                onClick={handleLogout}
                className="ml-auto p-1 rounded-full hover:bg-gray-100"
              >
                <LogOut className="h-5 w-5 text-gray-500" />
              </button>
            </div>
          </div>
        </div>
      </aside>
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile Header */}
        <header className="md:hidden bg-white shadow-sm p-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-blue-600">PayNest</h2>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg bg-gray-100"
          >
            {mobileMenuOpen ? (
              <X className="h-6 w-6 text-gray-600" />
            ) : (
              <Menu className="h-6 w-6 text-gray-600" />
            )}
          </button>
        </header>
        
        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white shadow-lg absolute top-16 left-0 right-0 z-10">
            <nav className="py-2">
              {navItems.map((item) => (
                <button
                  key={item.path}
                  onClick={() => handleNavigation(item.path)}
                  className={`
                    flex items-center px-4 py-3 text-sm font-medium w-full
                    ${location.pathname === item.path
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-gray-700 hover:bg-gray-100'}
                  `}
                >
                  <item.icon className="mr-3 h-5 w-5" />
                  <span>{item.label}</span>
                  {item.badge > 0 && (
                    <span className="ml-auto bg-red-500 text-white text-xs font-bold py-1 px-2 rounded-full">
                      {item.badge}
                    </span>
                  )}
                </button>
              ))}
              <button
                onClick={handleLogout}
                className="flex items-center px-4 py-3 text-sm font-medium w-full text-gray-700 hover:bg-gray-100"
              >
                <LogOut className="mr-3 h-5 w-5" />
                <span>Logout</span>
              </button>
            </nav>
          </div>
        )}
        
        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-gray-50">
          {children}
        </main>
      </div>
    </div>
  );
};

export default AppShell;