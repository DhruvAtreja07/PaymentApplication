import React from 'react';

interface AvatarProps {
  src?: string;
  alt?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  name?: string;
  status?: 'online' | 'offline' | 'away' | 'busy';
  className?: string;
}

const Avatar: React.FC<AvatarProps> = ({
  src,
  alt = 'User avatar',
  size = 'md',
  name,
  status,
  className = '',
}) => {
  const sizeClasses = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-12 h-12 text-base',
    xl: 'w-16 h-16 text-lg',
  };

  const statusClasses = {
    online: 'bg-green-500',
    offline: 'bg-gray-400',
    away: 'bg-yellow-500',
    busy: 'bg-red-500',
  };

  // Get initials from name
  const getInitials = () => {
    if (!name) return '';
    
    const nameArray = name.split(' ');
    if (nameArray.length === 1) return nameArray[0].charAt(0).toUpperCase();
    
    return (nameArray[0].charAt(0) + nameArray[nameArray.length - 1].charAt(0)).toUpperCase();
  };

  return (
    <div className={`relative rounded-full ${className}`}>
      {src ? (
        <img
          src={src}
          alt={alt}
          className={`${sizeClasses[size]} rounded-full object-cover`}
        />
      ) : (
        <div
          className={`${sizeClasses[size]} rounded-full bg-blue-100 text-blue-800 font-medium flex items-center justify-center`}
        >
          {getInitials()}
        </div>
      )}
      
      {status && (
        <span
          className={`absolute bottom-0 right-0 block rounded-full ring-2 ring-white ${statusClasses[status]}`}
          style={{ width: size === 'sm' ? '8px' : size === 'md' ? '10px' : '12px', height: size === 'sm' ? '8px' : size === 'md' ? '10px' : '12px' }}
        />
      )}
    </div>
  );
};

export default Avatar;