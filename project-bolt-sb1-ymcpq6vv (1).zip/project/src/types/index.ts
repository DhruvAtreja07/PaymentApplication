export interface User {
  id: string;
  fullName: string;
  username: string;
  phoneNumber: string;
  pin: string;
  walletBalance: number;
  profilePic?: string;
}

export interface Transaction {
  id: string;
  senderId: string;
  receiverId: string;
  amount: number;
  timestamp: number;
  type: 'send' | 'receive' | 'add';
  status: 'completed' | 'pending' | 'failed';
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: number;
  read: boolean;
}

export interface MoneyRequest {
  id: string;
  requesterId: string;
  requesteeId: string;
  amount: number;
  timestamp: number;
  status: 'pending' | 'accepted' | 'rejected';
  message?: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'transaction' | 'message' | 'request' | 'system';
  read: boolean;
  timestamp: number;
  actionId?: string;
}