import { User, Transaction, Message, MoneyRequest, Notification } from '../types';

export const mockUsers: User[] = [
  {
    id: 'user-1',
    fullName: 'John Doe',
    username: 'johndoe',
    phoneNumber: '+1234567890',
    pin: '1234',
    walletBalance: 5000,
    profilePic: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 'user-2',
    fullName: 'Jane Smith',
    username: 'janesmith',
    phoneNumber: '+0987654321',
    pin: '5678',
    walletBalance: 3500,
    profilePic: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 'user-3',
    fullName: 'Alice Johnson',
    username: 'alicej',
    phoneNumber: '+1122334455',
    pin: '4321',
    walletBalance: 2000,
    profilePic: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 'user-4',
    fullName: 'Bob Wilson',
    username: 'bobw',
    phoneNumber: '+5566778899',
    pin: '8765',
    walletBalance: 6500,
    profilePic: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
];

export const mockTransactions: Transaction[] = [
  {
    id: 'tx-1',
    senderId: 'user-1',
    receiverId: 'user-2',
    amount: 500,
    timestamp: Date.now() - 3600000 * 24 * 2, // 2 days ago
    type: 'send',
    status: 'completed',
  },
  {
    id: 'tx-2',
    senderId: 'user-2',
    receiverId: 'user-1',
    amount: 200,
    timestamp: Date.now() - 3600000 * 24, // 1 day ago
    type: 'send',
    status: 'completed',
  },
  {
    id: 'tx-3',
    senderId: 'user-3',
    receiverId: 'user-1',
    amount: 1000,
    timestamp: Date.now() - 3600000 * 12, // 12 hours ago
    type: 'send',
    status: 'completed',
  },
  {
    id: 'tx-4',
    senderId: 'system',
    receiverId: 'user-1',
    amount: 2000,
    timestamp: Date.now() - 3600000 * 6, // 6 hours ago
    type: 'add',
    status: 'completed',
  },
];

export const mockMessages: Message[] = [
  {
    id: 'msg-1',
    senderId: 'user-1',
    receiverId: 'user-2',
    content: 'Hey, how are you?',
    timestamp: Date.now() - 3600000 * 24 * 2, // 2 days ago
    read: true,
  },
  {
    id: 'msg-2',
    senderId: 'user-2',
    receiverId: 'user-1',
    content: 'I\'m good! How about you?',
    timestamp: Date.now() - 3600000 * 24 * 2 + 300000, // 2 days ago + 5 minutes
    read: true,
  },
  {
    id: 'msg-3',
    senderId: 'user-1',
    receiverId: 'user-2',
    content: 'Doing great! Just sent you some money for dinner last night.',
    timestamp: Date.now() - 3600000 * 24, // 1 day ago
    read: true,
  },
  {
    id: 'msg-4',
    senderId: 'user-2',
    receiverId: 'user-1',
    content: 'Got it, thanks!',
    timestamp: Date.now() - 3600000 * 24 + 600000, // 1 day ago + 10 minutes
    read: false,
  },
  {
    id: 'msg-5',
    senderId: 'user-3',
    receiverId: 'user-1',
    content: 'Hi John! I sent you the money I owed you.',
    timestamp: Date.now() - 3600000 * 12, // 12 hours ago
    read: false,
  },
];

export const mockRequests: MoneyRequest[] = [
  {
    id: 'req-1',
    requesterId: 'user-2',
    requesteeId: 'user-1',
    amount: 300,
    timestamp: Date.now() - 3600000 * 12, // 12 hours ago
    status: 'pending',
    message: 'For the concert tickets',
  },
  {
    id: 'req-2',
    requesterId: 'user-1',
    requesteeId: 'user-3',
    amount: 450,
    timestamp: Date.now() - 3600000 * 24, // 1 day ago
    status: 'accepted',
    message: 'Dinner at Italian restaurant',
  },
  {
    id: 'req-3',
    requesterId: 'user-4',
    requesteeId: 'user-1',
    amount: 750,
    timestamp: Date.now() - 3600000 * 36, // 1.5 days ago
    status: 'rejected',
    message: 'Basketball game tickets',
  },
];

export const mockNotifications: Notification[] = [
  {
    id: 'notif-1',
    userId: 'user-1',
    title: 'Money Received',
    message: 'You received $200 from Jane Smith',
    type: 'transaction',
    read: false,
    timestamp: Date.now() - 3600000 * 24, // 1 day ago
    actionId: 'tx-2',
  },
  {
    id: 'notif-2',
    userId: 'user-1',
    title: 'New Message',
    message: 'You have a new message from Jane Smith',
    type: 'message',
    read: true,
    timestamp: Date.now() - 3600000 * 24 + 600000, // 1 day ago + 10 minutes
    actionId: 'msg-4',
  },
  {
    id: 'notif-3',
    userId: 'user-1',
    title: 'Money Request',
    message: 'Jane Smith requested $300 for concert tickets',
    type: 'request',
    read: false,
    timestamp: Date.now() - 3600000 * 12, // 12 hours ago
    actionId: 'req-1',
  },
  {
    id: 'notif-4',
    userId: 'user-1',
    title: 'Money Received',
    message: 'You received $1000 from Alice Johnson',
    type: 'transaction',
    read: false,
    timestamp: Date.now() - 3600000 * 12, // 12 hours ago
    actionId: 'tx-3',
  },
];