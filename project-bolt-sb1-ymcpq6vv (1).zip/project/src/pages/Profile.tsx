import React from 'react';
import AppShell from '../components/layout/AppShell';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Avatar from '../components/ui/Avatar';
import { useAuthStore } from '../store/authStore';
import { Settings, Edit, CreditCard, Bell, Shield, LogOut } from 'lucide-react';

const Profile = () => {
  const { user, logout } = useAuthStore();

  const menuItems = [
    { icon: Settings, label: 'Account Settings', onClick: () => {} },
    { icon: CreditCard, label: 'Payment Methods', onClick: () => {} },
    { icon: Bell, label: 'Notifications', onClick: () => {} },
    { icon: Shield, label: 'Privacy & Security', onClick: () => {} },
  ];

  return (
    <AppShell>
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Card className="mb-8 p-6">
          <div className="flex items-center gap-6">
            <Avatar
              src={user?.avatar}
              alt={user?.name}
              className="w-24 h-24"
              fallback={user?.name?.[0] || '?'}
            />
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-gray-900">{user?.name}</h1>
              <p className="text-gray-500">{user?.email}</p>
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => {}}
              >
                <Edit className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
            </div>
          </div>
        </Card>

        <div className="space-y-4">
          {menuItems.map((item) => (
            <Card
              key={item.label}
              className="p-4 hover:bg-gray-50 transition-colors cursor-pointer"
              onClick={item.onClick}
            >
              <div className="flex items-center gap-4">
                <item.icon className="w-5 h-5 text-gray-500" />
                <span className="flex-1 font-medium">{item.label}</span>
              </div>
            </Card>
          ))}

          <Card
            className="p-4 hover:bg-red-50 transition-colors cursor-pointer"
            onClick={logout}
          >
            <div className="flex items-center gap-4 text-red-600">
              <LogOut className="w-5 h-5" />
              <span className="flex-1 font-medium">Logout</span>
            </div>
          </Card>
        </div>
      </div>
    </AppShell>
  );
};

export default Profile;