import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { User, KeyRound } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Card, { CardContent } from '../../components/ui/Card';
import PinInput from '../../components/auth/PinInput';

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const navigate = useNavigate();
  const { login } = useAuthStore();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username.trim()) {
      setError('Please enter your username');
      return;
    }
    
    if (pin.length !== 4) {
      setError('Please enter your 4-digit PIN');
      return;
    }
    
    setLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      const success = login(username, pin);
      
      if (success) {
        navigate('/dashboard');
      } else {
        setError('Invalid username or PIN');
        setLoading(false);
      }
    }, 800);
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-purple-50 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold text-blue-600 mb-2">PayNest</h1>
          <p className="text-gray-600">Fast, secure payments for everyone</p>
        </div>
        
        <Card className="w-full">
          <CardContent className="pt-6">
            <h2 className="text-2xl font-bold text-center mb-6">Welcome back</h2>
            
            <form onSubmit={handleSubmit}>
              <Input
                label="Username"
                placeholder="Enter your username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                icon={<User size={18} />}
                autoComplete="username"
              />
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  PIN
                </label>
                <PinInput
                  length={4}
                  onChange={(value) => setPin(value)}
                  error={pin.length > 0 && pin.length < 4 ? 'Please enter all 4 digits' : ''}
                />
              </div>
              
              {error && (
                <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm">
                  {error}
                </div>
              )}
              
              <Button
                type="submit"
                variant="primary"
                fullWidth
                disabled={loading}
                className="mb-4"
                icon={loading ? <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" /> : <KeyRound size={18} />}
              >
                {loading ? 'Logging in...' : 'Login'}
              </Button>
              
              <p className="text-center text-sm text-gray-600">
                Don't have an account?{' '}
                <Link to="/signup" className="text-blue-600 hover:underline font-medium">
                  Sign up
                </Link>
              </p>
            </form>
          </CardContent>
        </Card>
        
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500">
            By using PayNest, you agree to our{' '}
            <a href="#" className="text-blue-600 hover:underline">
              Terms of Service
            </a>{' '}
            and{' '}
            <a href="#" className="text-blue-600 hover:underline">
              Privacy Policy
            </a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;