import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { User, KeyRound, Phone, Search, Check, X } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Card, { CardContent } from '../../components/ui/Card';
import PinInput from '../../components/auth/PinInput';
import OtpInput from 'react-otp-input';

enum SignupStep {
  PERSONAL_INFO,
  PHONE_VERIFICATION,
  SECURITY,
}

const Signup: React.FC = () => {
  const [step, setStep] = useState<SignupStep>(SignupStep.PERSONAL_INFO);
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null);
  const [demoOtp, setDemoOtp] = useState(''); // For demo purposes
  
  const navigate = useNavigate();
  const { register, isUsernameAvailable, setTempPhone, setTempOtp, setVerificationComplete } = useAuthStore();
  
  const handleUsernameCheck = () => {
    if (username.length >= 3) {
      setUsernameAvailable(isUsernameAvailable(username));
    } else {
      setUsernameAvailable(null);
    }
  };
  
  const handlePersonalInfoNext = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!fullName.trim()) {
      setError('Please enter your full name');
      return;
    }
    
    if (!username.trim() || username.length < 3) {
      setError('Username must be at least 3 characters');
      return;
    }
    
    if (!usernameAvailable) {
      setError('This username is already taken');
      return;
    }
    
    if (!phoneNumber.trim() || phoneNumber.length < 10) {
      setError('Please enter a valid phone number');
      return;
    }
    
    setError('');
    setTempPhone(phoneNumber);
    
    // Generate a random 6-digit OTP for demo purposes
    const generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();
    setDemoOtp(generatedOtp);
    
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setStep(SignupStep.PHONE_VERIFICATION);
    }, 1000);
  };
  
  const handleVerificationNext = () => {
    if (!otp || otp.length !== 6) {
      setError('Please enter the complete OTP');
      return;
    }
    
    if (otp !== demoOtp) {
      setError('Invalid OTP code');
      return;
    }
    
    setError('');
    setTempOtp(otp);
    
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setVerificationComplete(true);
      setStep(SignupStep.SECURITY);
    }, 1000);
  };
  
  const handleCreateAccount = () => {
    if (!pin || pin.length !== 4) {
      setError('Please enter a 4-digit PIN');
      return;
    }
    
    if (pin !== confirmPin) {
      setError('PINs do not match');
      return;
    }
    
    setError('');
    
    // Register the user
    setLoading(true);
    setTimeout(() => {
      const success = register({
        fullName,
        username,
        phoneNumber,
        pin,
      });
      
      if (success) {
        navigate('/dashboard');
      } else {
        setError('Something went wrong. Please try again.');
        setLoading(false);
      }
    }, 1000);
  };
  
  const renderPersonalInfoStep = () => (
    <form onSubmit={handlePersonalInfoNext}>
      <Input
        label="Full Name"
        placeholder="Enter your full name"
        value={fullName}
        onChange={(e) => setFullName(e.target.value)}
        icon={<User size={18} />}
      />
      
      <div className="mb-4">
        <Input
          label="Username"
          placeholder="Choose a unique username"
          value={username}
          onChange={(e) => {
            setUsername(e.target.value);
            setUsernameAvailable(null);
          }}
          onBlur={handleUsernameCheck}
          icon={<Search size={18} />}
        />
        
        {usernameAvailable !== null && (
          <div className="mt-1 flex items-center">
            {usernameAvailable ? (
              <>
                <Check size={16} className="text-green-500 mr-1" />
                <span className="text-sm text-green-500">Username is available</span>
              </>
            ) : (
              <>
                <X size={16} className="text-red-500 mr-1" />
                <span className="text-sm text-red-500">Username is already taken</span>
              </>
            )}
          </div>
        )}
      </div>
      
      <Input
        label="Phone Number"
        placeholder="Enter your phone number"
        value={phoneNumber}
        onChange={(e) => setPhoneNumber(e.target.value)}
        type="tel"
        icon={<Phone size={18} />}
      />
      
      {error && (
        <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm">
          {error}
        </div>
      )}
      
      <Button
        type="submit"
        variant="primary"
        fullWidth
        disabled={loading}
        className="mb-4"
      >
        {loading ? (
          <>
            <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
            Continuing...
          </>
        ) : (
          'Continue'
        )}
      </Button>
      
      <p className="text-center text-sm text-gray-600">
        Already have an account?{' '}
        <Link to="/login" className="text-blue-600 hover:underline font-medium">
          Log in
        </Link>
      </p>
    </form>
  );
  
  const renderPhoneVerificationStep = () => (
    <div>
      <p className="text-center text-gray-600 mb-6">
        We've sent a 6-digit verification code to your phone number <strong>{phoneNumber}</strong>
      </p>
      
      {/* Demo OTP display */}
      <div className="mb-6 p-4 bg-blue-50 rounded-lg">
        <p className="text-sm text-blue-800 text-center">
          <strong>Demo Mode:</strong> Your verification code is <span className="font-mono font-bold">{demoOtp}</span>
        </p>
      </div>
      
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Enter Verification Code
        </label>
        <OtpInput
          value={otp}
          onChange={setOtp}
          numInputs={6}
          renderInput={(props) => <input {...props} />}
          inputStyle={{
            width: '40px',
            height: '48px',
            margin: '0 4px',
            padding: '0',
            borderRadius: '8px',
            border: '1px solid #CBD5E0',
            textAlign: 'center',
            fontSize: '16px',
            fontWeight: '500',
          }}
          containerStyle={{
            justifyContent: 'center',
          }}
        />
      </div>
      
      {error && (
        <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm">
          {error}
        </div>
      )}
      
      <div className="flex flex-col gap-3">
        <Button
          variant="primary"
          fullWidth
          onClick={handleVerificationNext}
          disabled={loading}
        >
          {loading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
              Verifying...
            </>
          ) : (
            'Verify'
          )}
        </Button>
        
        <Button variant="outline" fullWidth onClick={() => setStep(SignupStep.PERSONAL_INFO)}>
          Go Back
        </Button>
        
        <p className="text-center text-sm text-gray-600 mt-2">
          Didn't receive the code?{' '}
          <button
            type="button"
            className="text-blue-600 hover:underline font-medium"
            onClick={() => {
              // Generate a new OTP
              const newOtp = Math.floor(100000 + Math.random() * 900000).toString();
              setDemoOtp(newOtp);
              alert('New code generated!');
            }}
          >
            Resend
          </button>
        </p>
      </div>
    </div>
  );
  
  const renderSecurityStep = () => (
    <div>
      <p className="text-center text-gray-600 mb-6">
        Create a 4-digit PIN to secure your account
      </p>
      
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Set PIN
        </label>
        <PinInput
          length={4}
          onChange={(value) => setPin(value)}
          error={pin.length > 0 && pin.length < 4 ? 'Please enter all 4 digits' : ''}
        />
      </div>
      
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Confirm PIN
        </label>
        <PinInput
          length={4}
          onChange={(value) => setConfirmPin(value)}
          error={
            confirmPin.length === 4 && pin !== confirmPin
              ? 'PINs do not match'
              : ''
          }
        />
      </div>
      
      {error && (
        <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm">
          {error}
        </div>
      )}
      
      <div className="flex flex-col gap-3">
        <Button
          variant="primary"
          fullWidth
          onClick={handleCreateAccount}
          disabled={loading}
        >
          {loading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
              Creating Account...
            </>
          ) : (
            'Create Account'
          )}
        </Button>
        
        <Button variant="outline" fullWidth onClick={() => setStep(SignupStep.PHONE_VERIFICATION)}>
          Go Back
        </Button>
      </div>
    </div>
  );
  
  const renderStep = () => {
    switch (step) {
      case SignupStep.PERSONAL_INFO:
        return renderPersonalInfoStep();
      case SignupStep.PHONE_VERIFICATION:
        return renderPhoneVerificationStep();
      case SignupStep.SECURITY:
        return renderSecurityStep();
      default:
        return renderPersonalInfoStep();
    }
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-purple-50 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold text-blue-600 mb-2">PayNest</h1>
          <p className="text-gray-600">Fast, secure payments for everyone</p>
        </div>
        
        <Card className="w-full">
          <CardContent className="pt-6">
            <h2 className="text-2xl font-bold text-center mb-2">Create Account</h2>
            
            <div className="flex items-center justify-center mb-6">
              <div className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= SignupStep.PERSONAL_INFO ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
                  1
                </div>
                <div className={`w-16 h-1 ${step > SignupStep.PERSONAL_INFO ? 'bg-blue-600' : 'bg-gray-200'}`} />
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= SignupStep.PHONE_VERIFICATION ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
                  2
                </div>
                <div className={`w-16 h-1 ${step > SignupStep.PHONE_VERIFICATION ? 'bg-blue-600' : 'bg-gray-200'}`} />
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= SignupStep.SECURITY ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
                  3
                </div>
              </div>
            </div>
            
            {renderStep()}
          </CardContent>
        </Card>
        
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500">
            By creating an account, you agree to our{' '}
            <a href="#" className="text-blue-600 hover:underline">
              Terms of Service
            </a>{' '}
            and{' '}
            <a href="#" className="text-blue-600 hover:underline">
              Privacy Policy
            </a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Signup;