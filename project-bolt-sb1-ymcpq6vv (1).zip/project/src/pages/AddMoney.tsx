import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, DollarSign, Wallet } from 'lucide-react';
import AppShell from '../components/layout/AppShell';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import Input from '../components/ui/Input';
import { useAuthStore } from '../store/authStore';
import { useTransactionStore } from '../store/transactionStore';

const AddMoney: React.FC = () => {
  const [amount, setAmount] = useState('');
  const [selectedMethod, setSelectedMethod] = useState<'card' | 'bank' | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { addMoney } = useTransactionStore();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !selectedMethod) return;

    setLoading(true);
    const parsedAmount = parseFloat(amount);

    // Simulate payment processing
    setTimeout(() => {
      const success = addMoney(parsedAmount);
      if (success) {
        navigate('/dashboard');
      }
      setLoading(false);
    }, 1500);
  };

  return (
    <AppShell>
      <div className="max-w-2xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Add Money</h1>
        
        <Card>
          <div className="p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Amount</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <DollarSign className="h-5 w-5 text-gray-400" />
                  </div>
                  <Input
                    type="number"
                    placeholder="Enter amount"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="pl-10"
                    min="0"
                    step="0.01"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Payment Method</label>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => setSelectedMethod('card')}
                    className={`p-4 border rounded-lg flex flex-col items-center justify-center gap-2 transition-colors ${
                      selectedMethod === 'card'
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-blue-200'
                    }`}
                  >
                    <CreditCard className="h-6 w-6" />
                    <span className="text-sm font-medium">Credit/Debit Card</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedMethod('bank')}
                    className={`p-4 border rounded-lg flex flex-col items-center justify-center gap-2 transition-colors ${
                      selectedMethod === 'bank'
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-blue-200'
                    }`}
                  >
                    <Wallet className="h-6 w-6" />
                    <span className="text-sm font-medium">Bank Transfer</span>
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                fullWidth
                disabled={!amount || !selectedMethod || loading}
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
                    Processing...
                  </>
                ) : (
                  'Add Money'
                )}
              </Button>
            </form>
          </div>
        </Card>
      </div>
    </AppShell>
  );
};

export default AddMoney;