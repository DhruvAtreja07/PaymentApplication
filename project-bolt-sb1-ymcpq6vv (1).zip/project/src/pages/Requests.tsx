import React from 'react';
import AppShell from '../components/layout/AppShell';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { ArrowRight, Clock, CheckCircle, XCircle } from 'lucide-react';

const Requests = () => {
  return (
    <AppShell>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Money Requests</h1>
        
        <div className="grid gap-6">
          {/* Pending Requests */}
          <section>
            <h2 className="text-xl font-semibold mb-4">Pending Requests</h2>
            <div className="space-y-4">
              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <Clock className="w-6 h-6 text-yellow-500" />
                    <div>
                      <h3 className="font-medium">Request from Sarah Johnson</h3>
                      <p className="text-sm text-gray-600">For dinner last night</p>
                      <p className="text-lg font-semibold mt-1">$45.00</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      <XCircle className="w-4 h-4 mr-2" />
                      Decline
                    </Button>
                    <Button size="sm">
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Pay
                    </Button>
                  </div>
                </div>
              </Card>
            </div>
          </section>

          {/* Sent Requests */}
          <section>
            <h2 className="text-xl font-semibold mb-4">Sent Requests</h2>
            <div className="space-y-4">
              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <Clock className="w-6 h-6 text-blue-500" />
                    <div>
                      <h3 className="font-medium">Request to Mike Smith</h3>
                      <p className="text-sm text-gray-600">Group lunch</p>
                      <p className="text-lg font-semibold mt-1">$25.00</p>
                      <Badge className="mt-2" variant="outline">Pending</Badge>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    View Details
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </Card>
            </div>
          </section>
        </div>
      </div>
    </AppShell>
  );
};

export default Requests;