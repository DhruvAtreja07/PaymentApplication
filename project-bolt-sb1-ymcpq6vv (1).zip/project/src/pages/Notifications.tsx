import React from 'react';
import AppShell from '../components/layout/AppShell';

const Notifications: React.FC = () => {
  return (
    <AppShell>
      <div className="p-6">
        <h1 className="text-2xl font-bold mb-6">Notifications</h1>
        <div className="space-y-4">
          {/* Placeholder for notifications list */}
          <p className="text-gray-500">No new notifications</p>
        </div>
      </div>
    </AppShell>
  );
};

export default Notifications;