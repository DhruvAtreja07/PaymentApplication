import React from 'react';
import AppShell from '../components/layout/AppShell';
import Card, { CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { ArrowUpRight, ArrowDownLeft } from 'lucide-react';

interface Transaction {
  id: string;
  type: 'send' | 'receive';
  amount: number;
  currency: string;
  user: {
    name: string;
    avatar?: string;
  };
  date: string;
  status: 'completed' | 'pending' | 'failed';
}

const Transactions: React.FC = () => {
  // In a real app, this would come from your transaction store
  const transactions: Transaction[] = [
    {
      id: '1',
      type: 'send',
      amount: 50.00,
      currency: 'USD',
      user: {
        name: 'John Doe',
      },
      date: '2024-01-20T10:30:00Z',
      status: 'completed'
    },
    {
      id: '2',
      type: 'receive',
      amount: 25.00,
      currency: 'USD',
      user: {
        name: 'Jane Smith',
      },
      date: '2024-01-19T15:45:00Z',
      status: 'completed'
    }
  ];

  const getStatusColor = (status: Transaction['status']) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <AppShell>
      <div className="p-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Transaction History</h1>
        
        <div className="space-y-4">
          {transactions.map((transaction) => (
            <Card key={transaction.id} className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className={`p-2 rounded-full ${
                    transaction.type === 'send' ? 'bg-red-100' : 'bg-green-100'
                  }`}>
                    {transaction.type === 'send' ? (
                      <ArrowUpRight className={`w-5 h-5 ${
                        transaction.type === 'send' ? 'text-red-600' : 'text-green-600'
                      }`} />
                    ) : (
                      <ArrowDownLeft className={`w-5 h-5 ${
                        transaction.type === 'send' ? 'text-red-600' : 'text-green-600'
                      }`} />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">
                      {transaction.type === 'send' ? 'Sent to' : 'Received from'} {transaction.user.name}
                    </p>
                    <p className="text-sm text-gray-500">{formatDate(transaction.date)}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <p className={`font-semibold ${
                    transaction.type === 'send' ? 'text-red-600' : 'text-green-600'
                  }`}>
                    {transaction.type === 'send' ? '-' : '+'}${transaction.amount.toFixed(2)}
                  </p>
                  <Badge className={`${getStatusColor(transaction.status)}`}>
                    {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                  </Badge>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </AppShell>
  );
};

export default Transactions;