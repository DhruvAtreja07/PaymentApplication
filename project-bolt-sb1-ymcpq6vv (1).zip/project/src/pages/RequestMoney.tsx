import React from 'react';
import AppShell from '../components/layout/AppShell';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { DollarSign, Search, Users } from 'lucide-react';
import { Avatar } from '../components/ui/Avatar';

const RequestMoney: React.FC = () => {
  const [amount, setAmount] = React.useState('');
  const [searchQuery, setSearchQuery] = React.useState('');
  const [selectedUser, setSelectedUser] = React.useState<{id: string; name: string; email: string} | null>(null);

  // Mock users data - in a real app, this would come from your backend
  const mockUsers = [
    { id: '1', name: 'Alice Johnson', email: 'alice@example.com' },
    { id: '2', name: 'Bob Smith', email: 'bob@example.com' },
    { id: '3', name: 'Carol White', email: 'carol@example.com' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle request money logic here
  };

  return (
    <AppShell>
      <div className="max-w-2xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Request Money</h1>
        
        <Card className="p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">From User</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <Input
                  type="text"
                  placeholder="Search users..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              {/* User selection list */}
              {searchQuery && !selectedUser && (
                <div className="mt-2 border rounded-lg divide-y">
                  {mockUsers
                    .filter(user => 
                      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      user.email.toLowerCase().includes(searchQuery.toLowerCase())
                    )
                    .map(user => (
                      <button
                        key={user.id}
                        type="button"
                        className="w-full p-3 flex items-center gap-3 hover:bg-gray-50 transition-colors"
                        onClick={() => {
                          setSelectedUser(user);
                          setSearchQuery('');
                        }}
                      >
                        <Avatar />
                        <div className="text-left">
                          <div className="font-medium">{user.name}</div>
                          <div className="text-sm text-gray-500">{user.email}</div>
                        </div>
                      </button>
                    ))
                  }
                </div>
              )}

              {/* Selected user display */}
              {selectedUser && (
                <div className="mt-2 p-3 border rounded-lg flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar />
                    <div>
                      <div className="font-medium">{selectedUser.name}</div>
                      <div className="text-sm text-gray-500">{selectedUser.email}</div>
                    </div>
                  </div>
                  <button
                    type="button"
                    className="text-sm text-red-600 hover:text-red-700"
                    onClick={() => setSelectedUser(null)}
                  >
                    Change
                  </button>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Amount</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <DollarSign className="h-5 w-5 text-gray-400" />
                </div>
                <Input
                  type="number"
                  placeholder="Enter amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="pl-10"
                  min="0"
                  step="0.01"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Note (Optional)</label>
              <textarea
                className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                rows={3}
                placeholder="Add a note to your request..."
              />
            </div>

            <Button
              type="submit"
              className="w-full"
              disabled={!amount || !selectedUser}
            >
              Request Money
            </Button>
          </form>
        </Card>
      </div>
    </AppShell>
  );
};

export default RequestMoney;