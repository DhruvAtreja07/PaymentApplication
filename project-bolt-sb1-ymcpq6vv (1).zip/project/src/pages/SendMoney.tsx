import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ChevronLeft, Send, Search, DollarSign, Check } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { useTransactionStore } from '../store/transactionStore';
import { useNotificationStore } from '../store/notificationStore';
import { mockUsers } from '../data/mockData';
import AppShell from '../components/layout/AppShell';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Card, { CardContent } from '../components/ui/Card';
import Avatar from '../components/ui/Avatar';
import PinInput from '../components/auth/PinInput';

const SendMoney: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const preSelectedUserId = queryParams.get('to');
  
  const { currentUser } = useAuthStore();
  const { sendMoney } = useTransactionStore();
  const { addNotification } = useNotificationStore();
  
  const [step, setStep] = useState(preSelectedUserId ? 1 : 0);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState<typeof mockUsers[0] | null>(null);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  
  useEffect(() => {
    // If a user ID is provided in the URL, preselect that user
    if (preSelectedUserId) {
      const user = mockUsers.find(u => u.id === preSelectedUserId);
      if (user) {
        setSelectedUser(user);
      }
    }
  }, [preSelectedUserId]);
  
  const filteredUsers = mockUsers.filter(
    (user) =>
      user.id !== currentUser?.id &&
      (user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.fullName.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  
  const handleUserSelect = (user: typeof mockUsers[0]) => {
    setSelectedUser(user);
    setStep(1);
  };
  
  const handleAmountSubmit = () => {
    const parsedAmount = parseFloat(amount);
    
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('Please enter a valid amount');
      return;
    }
    
    if (parsedAmount > (currentUser?.walletBalance || 0)) {
      setError('Insufficient balance');
      return;
    }
    
    setError('');
    setStep(2);
  };
  
  const handleSendMoney = () => {
    if (pin.length !== 4) {
      setError('Please enter your 4-digit PIN');
      return;
    }
    
    if (pin !== currentUser?.pin) {
      setError('Incorrect PIN');
      return;
    }
    
    if (!selectedUser) {
      setError('No recipient selected');
      return;
    }
    
    const parsedAmount = parseFloat(amount);
    
    setLoading(true);
    setTimeout(() => {
      const success = sendMoney(selectedUser.id, parsedAmount);
      
      if (success) {
        // Create a notification for the recipient
        addNotification({
          userId: selectedUser.id,
          title: 'Money Received',
          message: `You received $${parsedAmount.toFixed(2)} from ${currentUser?.username}`,
          type: 'transaction',
          read: false,
        });
        
        setSuccess(true);
      } else {
        setError('Transaction failed. Please try again.');
      }
      
      setLoading(false);
    }, 1000);
  };
  
  const renderUserSelectionStep = () => (
    <Card>
      <CardContent className="py-6">
        <h2 className="text-xl font-bold mb-4">Send Money To</h2>
        
        <div className="relative mb-4">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search by username or name"
            className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="space-y-3 max-h-80 overflow-y-auto">
          {filteredUsers.length > 0 ? (
            filteredUsers.map((user) => (
              <div
                key={user.id}
                className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 cursor-pointer border border-gray-100"
                onClick={() => handleUserSelect(user)}
              >
                <div className="flex items-center">
                  <Avatar
                    src={user.profilePic}
                    name={user.fullName}
                    size="md"
                  />
                  <div className="ml-3">
                    <p className="font-medium">{user.fullName}</p>
                    <p className="text-sm text-gray-500">@{user.username}</p>
                  </div>
                </div>
                <Send size={18} className="text-gray-400" />
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>No users found</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
  
  const renderAmountStep = () => (
    <Card>
      <CardContent className="py-6">
        <h2 className="text-xl font-bold mb-4">Send Money</h2>
        
        <div className="mb-6 text-center">
          <div className="flex items-center justify-center gap-2">
            <Avatar
              src={selectedUser?.profilePic}
              name={selectedUser?.fullName || ''}
              size="md"
            />
            <div>
              <p className="font-medium">{selectedUser?.fullName}</p>
              <p className="text-sm text-gray-500">@{selectedUser?.username}</p>
            </div>
          </div>
        </div>
        
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Amount
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <DollarSign size={18} className="text-gray-400" />
            </div>
            <input
              type="number"
              placeholder="0.00"
              className="pl-10 pr-4 py-3 text-xl border border-gray-300 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              min="0"
              step="0.01"
            />
          </div>
          <p className="text-sm text-gray-500 mt-1">
            Available balance: ${currentUser?.walletBalance.toFixed(2)}
          </p>
        </div>
        
        <Input
          label="Add a note (optional)"
          placeholder="What's this for?"
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
        
        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm">
            {error}
          </div>
        )}
        
        <div className="flex space-x-3">
          <Button
            variant="outline"
            onClick={() => setStep(0)}
            className="flex-1"
          >
            Back
          </Button>
          <Button
            variant="primary"
            onClick={handleAmountSubmit}
            className="flex-1"
          >
            Continue
          </Button>
        </div>
      </CardContent>
    </Card>
  );
  
  const renderConfirmationStep = () => (
    <Card>
      <CardContent className="py-6">
        <h2 className="text-xl font-bold mb-4">Confirm Payment</h2>
        
        <div className="bg-gray-50 rounded-lg p-4 mb-6">
          <div className="flex justify-between mb-2">
            <span className="text-gray-600">To</span>
            <span className="font-medium">{selectedUser?.fullName}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="text-gray-600">Amount</span>
            <span className="font-medium">${parseFloat(amount).toFixed(2)}</span>
          </div>
          {note && (
            <div className="flex justify-between">
              <span className="text-gray-600">Note</span>
              <span className="font-medium">{note}</span>
            </div>
          )}
        </div>
        
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Enter your PIN to confirm
          </label>
          <PinInput
            length={4}
            onChange={(value) => setPin(value)}
            error={error.includes('PIN') ? error : ''}
          />
        </div>
        
        {error && !error.includes('PIN') && (
          <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm">
            {error}
          </div>
        )}
        
        <div className="flex space-x-3">
          <Button
            variant="outline"
            onClick={() => setStep(1)}
            className="flex-1"
            disabled={loading}
          >
            Back
          </Button>
          <Button
            variant="primary"
            onClick={handleSendMoney}
            className="flex-1"
            disabled={loading}
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
                Processing...
              </>
            ) : (
              'Send Money'
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
  
  const renderSuccessStep = () => (
    <Card>
      <CardContent className="py-8 text-center">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Check size={32} className="text-green-600" />
        </div>
        
        <h2 className="text-2xl font-bold mb-2">Payment Successful!</h2>
        <p className="text-gray-600 mb-2">
          You've sent ${parseFloat(amount).toFixed(2)} to {selectedUser?.fullName}
        </p>
        <p className="text-sm text-gray-500 mb-6">
          Transaction completed successfully
        </p>
        
        <div className="flex space-x-3 justify-center">
          <Button
            variant="outline"
            onClick={() => navigate('/transactions')}
          >
            View Transactions
          </Button>
          <Button
            variant="primary"
            onClick={() => navigate('/dashboard')}
          >
            Back to Home
          </Button>
        </div>
      </CardContent>
    </Card>
  );
  
  const renderCurrentStep = () => {
    if (success) {
      return renderSuccessStep();
    }
    
    switch (step) {
      case 0:
        return renderUserSelectionStep();
      case 1:
        return renderAmountStep();
      case 2:
        return renderConfirmationStep();
      default:
        return renderUserSelectionStep();
    }
  };
  
  return (
    <AppShell>
      <div className="max-w-lg mx-auto">
        {!success && (
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-gray-600 mb-6 hover:text-gray-900"
          >
            <ChevronLeft size={20} className="mr-1" />
            <span>Back</span>
          </button>
        )}
        
        {renderCurrentStep()}
      </div>
    </AppShell>
  );
};

export default SendMoney;