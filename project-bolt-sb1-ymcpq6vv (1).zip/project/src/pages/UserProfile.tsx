import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, Send, MessageSquare } from 'lucide-react';
import { mockUsers } from '../data/mockData';
import AppShell from '../components/layout/AppShell';
import Button from '../components/ui/Button';
import Card, { CardContent } from '../components/ui/Card';
import Avatar from '../components/ui/Avatar';

const UserProfile: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();
  
  
  // Find the user from mock data
  const user = mockUsers.find(u => u.id === userId);
  
  if (!user) {
    return (
      <AppShell>
        <div className="max-w-lg mx-auto mt-8">
          <Card>
            <CardContent className="py-8 text-center">
              <h2 className="text-xl font-bold mb-2">User Not Found</h2>
              <p className="text-gray-600 mb-4">
                The user you're looking for doesn't exist or has been removed.
              </p>
              <Button
                variant="outline"
                onClick={() => navigate('/dashboard')}
                icon={<ChevronLeft size={18} />}
              >
                Back to Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
      </AppShell>
    );
  }
  
  return (
    <AppShell>
      <div className="max-w-2xl mx-auto">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-gray-600 mb-6 hover:text-gray-900"
        >
          <ChevronLeft size={20} className="mr-1" />
          <span>Back</span>
        </button>
        
        <Card>
          <CardContent className="py-8">
            <div className="flex flex-col items-center">
              <Avatar 
                src={user.profilePic} 
                name={user.fullName} 
                size="xl" 
              />
              
              <h1 className="text-2xl font-bold mt-4">{user.fullName}</h1>
              <p className="text-gray-600">@{user.username}</p>
              
              <div className="flex space-x-3 mt-6">
                <Button
                  variant="primary"
                  onClick={() => navigate(`/send-money?to=${user.id}`)}
                  icon={<Send size={18} />}
                >
                  Send Money
                </Button>
                <Button
                  variant="outline"
                  onClick={() => navigate(`/chat/${user.id}`)}
                  icon={<MessageSquare size={18} />}
                >
                  Message
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
};

export default UserProfile;