import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Send, Plus, ArrowDownLeft, ArrowUpRight, Wallet } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { useTransactionStore } from '../store/transactionStore';
import AppShell from '../components/layout/AppShell';
import Button from '../components/ui/Button';
import Card, { CardContent, CardHeader } from '../components/ui/Card';
import Avatar from '../components/ui/Avatar';
import { mockUsers } from '../data/mockData';

const Dashboard: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const { currentUser } = useAuthStore();
  const { getTransactionHistory } = useTransactionStore();
  
  const recentTransactions = getTransactionHistory().slice(0, 3);
  
  const filteredUsers = mockUsers.filter(
    (user) =>
      user.id !== currentUser?.id &&
      (user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.fullName.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };
  
  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    });
  };
  
  return (
    <AppShell>
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-800">
            Welcome, {currentUser?.fullName?.split(' ')[0]}
          </h1>
          <p className="text-gray-600">Manage your payments and transactions securely</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gradient-to-r from-blue-500 to-blue-700 text-white">
            <CardContent className="py-6">
              <div className="flex items-center mb-2">
                <Wallet className="mr-2" size={20} />
                <h3 className="text-lg font-semibold">Wallet Balance</h3>
              </div>
              <p className="text-3xl font-bold">
                {formatCurrency(currentUser?.walletBalance || 0)}
              </p>
              <div className="mt-4 flex space-x-2">
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => navigate('/add-money')}
                  icon={<Plus size={16} />}
                >
                  Add Money
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card className="col-span-1 md:col-span-2">
            <CardHeader className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Quick Actions</h3>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <Button
                  variant="outline"
                  fullWidth
                  onClick={() => navigate('/send-money')}
                  icon={<Send size={18} />}
                  className="h-12"
                >
                  Send Money
                </Button>
                <Button
                  variant="outline"
                  fullWidth
                  onClick={() => navigate('/request-money')}
                  icon={<ArrowDownLeft size={18} />}
                  className="h-12"
                >
                  Request Money
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Recent Transactions</h3>
              <Button
                size="sm"
                variant="outline"
                onClick={() => navigate('/transactions')}
              >
                See All
              </Button>
            </CardHeader>
            <CardContent>
              {recentTransactions.length > 0 ? (
                <div className="space-y-4">
                  {recentTransactions.map((tx) => {
                    const isReceiving = tx.receiverId === currentUser?.id;
                    const otherUser = mockUsers.find(
                      (user) => user.id === (isReceiving ? tx.senderId : tx.receiverId)
                    );
                    
                    return (
                      <div key={tx.id} className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="p-2 rounded-full bg-gray-100">
                            {isReceiving ? (
                              <ArrowDownLeft
                                size={20}
                                className="text-green-500"
                              />
                            ) : (
                              <ArrowUpRight
                                size={20}
                                className="text-blue-500"
                              />
                            )}
                          </div>
                          <div className="ml-3">
                            <p className="font-medium">
                              {tx.type === 'add' 
                                ? 'Added to Wallet' 
                                : isReceiving 
                                  ? `Received from ${otherUser?.username || 'Unknown'}`
                                  : `Sent to ${otherUser?.username || 'Unknown'}`
                              }
                            </p>
                            <p className="text-sm text-gray-500">{formatDate(tx.timestamp)}</p>
                          </div>
                        </div>
                        <p className={`font-semibold ${isReceiving ? 'text-green-600' : 'text-gray-900'}`}>
                          {isReceiving ? '+' : '-'}{formatCurrency(tx.amount)}
                        </p>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-6 text-gray-500">
                  <p>No recent transactions</p>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Find Users</h3>
            </CardHeader>
            <CardContent>
              <div className="relative mb-4">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search size={18} className="text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search by username or name"
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {searchQuery.trim() !== '' ? (
                  filteredUsers.length > 0 ? (
                    filteredUsers.map((user) => (
                      <div
                        key={user.id}
                        className="flex items-center justify-between p-2 rounded-lg hover:bg-gray-50 cursor-pointer"
                        onClick={() => navigate(`/user/${user.id}`)}
                      >
                        <div className="flex items-center">
                          <Avatar
                            src={user.profilePic}
                            name={user.fullName}
                            size="md"
                          />
                          <div className="ml-3">
                            <p className="font-medium">{user.fullName}</p>
                            <p className="text-sm text-gray-500">@{user.username}</p>
                          </div>
                        </div>
                        <Send size={18} className="text-gray-400" />
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-4 text-gray-500">
                      <p>No users found</p>
                    </div>
                  )
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    <p>Search for users to send money or messages</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
};

export default Dashboard;