import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User } from '../types';
import { mockUsers } from '../data/mockData';

interface AuthState {
  isAuthenticated: boolean;
  currentUser: User | null;
  tempPhone: string | null;
  tempOtp: string | null;
  verificationComplete: boolean;
  
  // Auth actions
  setTempPhone: (phone: string) => void;
  setTempOtp: (otp: string) => void;
  setVerificationComplete: (complete: boolean) => void;
  login: (username: string, pin: string) => boolean;
  logout: () => void;
  register: (user: Omit<User, 'id' | 'walletBalance'>) => boolean;
  resetPin: (username: string, newPin: string) => boolean;
  
  // User data actions
  updateWalletBalance: (amount: number) => void;
  isUsernameAvailable: (username: string) => boolean;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      isAuthenticated: false,
      currentUser: null,
      tempPhone: null,
      tempOtp: null,
      verificationComplete: false,
      
      setTempPhone: (phone) => set({ tempPhone: phone }),
      
      setTempOtp: (otp) => set({ tempOtp: otp }),
      
      setVerificationComplete: (complete) => set({ verificationComplete: complete }),
      
      login: (username, pin) => {
        // In a real app, this would make an API call with proper authentication
        const user = mockUsers.find(
          (u) => u.username === username && u.pin === pin
        );
        
        if (user) {
          set({ isAuthenticated: true, currentUser: user });
          return true;
        }
        return false;
      },
      
      logout: () => {
        set({
          isAuthenticated: false,
          currentUser: null,
          tempPhone: null,
          tempOtp: null,
          verificationComplete: false,
        });
      },
      
      register: (userData) => {
        // Check if username is available
        if (!get().isUsernameAvailable(userData.username)) {
          return false;
        }
        
        // In a real app, this would make an API call to register the user
        const newUser: User = {
          id: `user-${Date.now()}`,
          ...userData,
          walletBalance: 1000, // Starting balance for demo
        };
        
        // For demo purposes, we're adding the user directly to state
        set({ isAuthenticated: true, currentUser: newUser });
        
        // In a real app, we would save this to a database
        mockUsers.push(newUser);
        
        return true;
      },
      
      resetPin: (username, newPin) => {
        // In a real app, this would be an API call
        const userIndex = mockUsers.findIndex((u) => u.username === username);
        
        if (userIndex >= 0) {
          mockUsers[userIndex].pin = newPin;
          
          // If this is the current user, update the current user as well
          if (get().currentUser?.username === username) {
            set({
              currentUser: {
                ...get().currentUser!,
                pin: newPin,
              },
            });
          }
          
          return true;
        }
        
        return false;
      },
      
      updateWalletBalance: (amount) => {
        if (!get().currentUser) return;
        
        set({
          currentUser: {
            ...get().currentUser!,
            walletBalance: get().currentUser!.walletBalance + amount,
          },
        });
        
        // Update in mock data too
        const userIndex = mockUsers.findIndex(
          (u) => u.id === get().currentUser!.id
        );
        
        if (userIndex >= 0) {
          mockUsers[userIndex].walletBalance += amount;
        }
      },
      
      isUsernameAvailable: (username) => {
        return !mockUsers.some((u) => u.username === username);
      },
    }),
    {
      name: 'paynest-auth-storage',
      partialize: (state) => ({
        isAuthenticated: state.isAuthenticated,
        currentUser: state.currentUser,
      }),
    }
  )
);