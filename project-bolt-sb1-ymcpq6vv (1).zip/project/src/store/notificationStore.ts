import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Notification } from '../types';
import { mockNotifications } from '../data/mockData';
import { useAuthStore } from './authStore';
import { v4 as uuidv4 } from 'uuid';

interface NotificationState {
  notifications: Notification[];
  
  // Notification actions
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp'>) => void;
  markAsRead: (notificationId: string) => void;
  markAllAsRead: () => void;
  getUnreadCount: () => number;
  getUserNotifications: () => Notification[];
}

export const useNotificationStore = create<NotificationState>()(
  persist(
    (set, get) => ({
      notifications: [...mockNotifications],
      
      addNotification: (notification) => {
        const newNotification: Notification = {
          id: uuidv4(),
          ...notification,
          timestamp: Date.now(),
        };
        
        set({ notifications: [newNotification, ...get().notifications] });
      },
      
      markAsRead: (notificationId) => {
        set({
          notifications: get().notifications.map((notif) =>
            notif.id === notificationId ? { ...notif, read: true } : notif
          ),
        });
      },
      
      markAllAsRead: () => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return;
        
        set({
          notifications: get().notifications.map((notif) =>
            notif.userId === currentUser.id ? { ...notif, read: true } : notif
          ),
        });
      },
      
      getUnreadCount: () => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return 0;
        
        return get().notifications.filter(
          (notif) => notif.userId === currentUser.id && !notif.read
        ).length;
      },
      
      getUserNotifications: () => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return [];
        
        return get().notifications.filter(
          (notif) => notif.userId === currentUser.id
        ).sort((a, b) => b.timestamp - a.timestamp);
      },
    }),
    {
      name: 'paynest-notification-storage',
    }
  )
);