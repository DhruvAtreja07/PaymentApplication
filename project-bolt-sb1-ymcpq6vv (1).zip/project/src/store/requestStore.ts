import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { MoneyRequest } from '../types';
import { mockRequests } from '../data/mockData';
import { useAuthStore } from './authStore';
import { useTransactionStore } from './transactionStore';
import { v4 as uuidv4 } from 'uuid';

interface RequestState {
  requests: MoneyRequest[];
  
  // Request actions
  requestMoney: (requesteeId: string, amount: number, message?: string) => boolean;
  acceptRequest: (requestId: string) => boolean;
  rejectRequest: (requestId: string) => boolean;
  getIncomingRequests: () => MoneyRequest[];
  getOutgoingRequests: () => MoneyRequest[];
  getPendingRequestsCount: () => number;
}

export const useRequestStore = create<RequestState>()(
  persist(
    (set, get) => ({
      requests: [...mockRequests],
      
      requestMoney: (requesteeId, amount, message) => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return false;
        
        const newRequest: MoneyRequest = {
          id: uuidv4(),
          requesterId: currentUser.id,
          requesteeId,
          amount,
          timestamp: Date.now(),
          status: 'pending',
          message,
        };
        
        set({ requests: [...get().requests, newRequest] });
        
        return true;
      },
      
      acceptRequest: (requestId) => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return false;
        
        // Find the request
        const request = get().requests.find((req) => req.id === requestId);
        
        if (!request || request.requesteeId !== currentUser.id) return false;
        
        // Check if user has enough balance
        if (currentUser.walletBalance < request.amount) return false;
        
        // Process the payment
        const success = useTransactionStore.getState().sendMoney(
          request.requesterId,
          request.amount
        );
        
        if (!success) return false;
        
        // Update the request status
        set({
          requests: get().requests.map((req) =>
            req.id === requestId ? { ...req, status: 'accepted' } : req
          ),
        });
        
        return true;
      },
      
      rejectRequest: (requestId) => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return false;
        
        // Find the request
        const request = get().requests.find((req) => req.id === requestId);
        
        if (!request || request.requesteeId !== currentUser.id) return false;
        
        // Update the request status
        set({
          requests: get().requests.map((req) =>
            req.id === requestId ? { ...req, status: 'rejected' } : req
          ),
        });
        
        return true;
      },
      
      getIncomingRequests: () => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return [];
        
        return get().requests.filter(
          (req) => req.requesteeId === currentUser.id
        ).sort((a, b) => b.timestamp - a.timestamp);
      },
      
      getOutgoingRequests: () => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return [];
        
        return get().requests.filter(
          (req) => req.requesterId === currentUser.id
        ).sort((a, b) => b.timestamp - a.timestamp);
      },
      
      getPendingRequestsCount: () => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return 0;
        
        return get().requests.filter(
          (req) => req.requesteeId === currentUser.id && req.status === 'pending'
        ).length;
      },
    }),
    {
      name: 'paynest-request-storage',
    }
  )
);