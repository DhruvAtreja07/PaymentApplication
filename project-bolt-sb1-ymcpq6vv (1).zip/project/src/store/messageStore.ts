import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Message } from '../types';
import { mockMessages } from '../data/mockData';
import { useAuthStore } from './authStore';
import { v4 as uuidv4 } from 'uuid';

interface MessageState {
  messages: Message[];
  currentChat: string | null;
  
  // Message actions
  sendMessage: (receiverId: string, content: string) => boolean;
  getConversation: (userId: string) => Message[];
  getAllConversations: () => { userId: string; lastMessage: Message }[];
  setCurrentChat: (userId: string | null) => void;
  markAsRead: (messageId: string) => void;
  getUnreadCount: (userId?: string) => number;
}

export const useMessageStore = create<MessageState>()(
  persist(
    (set, get) => ({
      messages: [...mockMessages],
      currentChat: null,
      
      sendMessage: (receiverId, content) => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return false;
        
        const newMessage: Message = {
          id: uuidv4(),
          senderId: currentUser.id,
          receiverId,
          content,
          timestamp: Date.now(),
          read: false,
        };
        
        set({ messages: [...get().messages, newMessage] });
        
        return true;
      },
      
      getConversation: (userId) => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return [];
        
        return get().messages.filter(
          (msg) =>
            (msg.senderId === currentUser.id && msg.receiverId === userId) ||
            (msg.senderId === userId && msg.receiverId === currentUser.id)
        ).sort((a, b) => a.timestamp - b.timestamp);
      },
      
      getAllConversations: () => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return [];
        
        // Get all unique user IDs the current user has messaged with
        const conversations = get().messages.filter(
          (msg) => msg.senderId === currentUser.id || msg.receiverId === currentUser.id
        );
        
        const uniqueUserIds = new Set<string>();
        
        conversations.forEach(msg => {
          if (msg.senderId === currentUser.id) {
            uniqueUserIds.add(msg.receiverId);
          } else {
            uniqueUserIds.add(msg.senderId);
          }
        });
        
        // Get the last message for each conversation
        return Array.from(uniqueUserIds).map(userId => {
          const userMessages = get().getConversation(userId);
          const lastMessage = userMessages[userMessages.length - 1];
          
          return {
            userId,
            lastMessage,
          };
        }).sort((a, b) => b.lastMessage.timestamp - a.lastMessage.timestamp);
      },
      
      setCurrentChat: (userId) => {
        set({ currentChat: userId });
        
        // Mark all messages from this user as read
        if (userId) {
          const currentUser = useAuthStore.getState().currentUser;
          
          if (currentUser) {
            const updatedMessages = get().messages.map((msg) => {
              if (msg.senderId === userId && msg.receiverId === currentUser.id && !msg.read) {
                return { ...msg, read: true };
              }
              return msg;
            });
            
            set({ messages: updatedMessages });
          }
        }
      },
      
      markAsRead: (messageId) => {
        set({
          messages: get().messages.map((msg) =>
            msg.id === messageId ? { ...msg, read: true } : msg
          ),
        });
      },
      
      getUnreadCount: (userId) => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return 0;
        
        if (userId) {
          // Count unread messages from a specific user
          return get().messages.filter(
            (msg) =>
              msg.senderId === userId &&
              msg.receiverId === currentUser.id &&
              !msg.read
          ).length;
        } else {
          // Count all unread messages
          return get().messages.filter(
            (msg) => msg.receiverId === currentUser.id && !msg.read
          ).length;
        }
      },
    }),
    {
      name: 'paynest-message-storage',
    }
  )
);