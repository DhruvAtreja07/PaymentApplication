import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Transaction } from '../types';
import { mockTransactions } from '../data/mockData';
import { useAuthStore } from './authStore';
import { v4 as uuidv4 } from 'uuid';

interface TransactionState {
  transactions: Transaction[];
  
  // Transaction actions
  sendMoney: (receiverId: string, amount: number) => boolean;
  addMoney: (amount: number) => boolean;
  getTransactionHistory: () => Transaction[];
  getSentTransactions: () => Transaction[];
  getReceivedTransactions: () => Transaction[];
  filterTransactions: (type?: 'send' | 'receive' | 'add', status?: 'completed' | 'pending' | 'failed') => Transaction[];
}

export const useTransactionStore = create<TransactionState>()(
  persist(
    (set, get) => ({
      transactions: [...mockTransactions],
      
      sendMoney: (receiverId, amount) => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return false;
        
        // Check if user has enough balance
        if (currentUser.walletBalance < amount) return false;
        
        // Create a new transaction
        const newTransaction: Transaction = {
          id: uuidv4(),
          senderId: currentUser.id,
          receiverId,
          amount,
          timestamp: Date.now(),
          type: 'send',
          status: 'completed',
        };
        
        // Update wallet balance
        useAuthStore.getState().updateWalletBalance(-amount);
        
        // In a real app, we would update the receiver's balance here too
        // For demo purposes, we'll simulate this by updating our mock data
        
        // Add the transaction
        set({ transactions: [...get().transactions, newTransaction] });
        
        return true;
      },
      
      addMoney: (amount) => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return false;
        
        // Create a new transaction
        const newTransaction: Transaction = {
          id: uuidv4(),
          senderId: 'system',
          receiverId: currentUser.id,
          amount,
          timestamp: Date.now(),
          type: 'add',
          status: 'completed',
        };
        
        // Update wallet balance
        useAuthStore.getState().updateWalletBalance(amount);
        
        // Add the transaction
        set({ transactions: [...get().transactions, newTransaction] });
        
        return true;
      },
      
      getTransactionHistory: () => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return [];
        
        return get().transactions.filter(
          (tx) => tx.senderId === currentUser.id || tx.receiverId === currentUser.id
        ).sort((a, b) => b.timestamp - a.timestamp);
      },
      
      getSentTransactions: () => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return [];
        
        return get().transactions.filter(
          (tx) => tx.senderId === currentUser.id && tx.type === 'send'
        ).sort((a, b) => b.timestamp - a.timestamp);
      },
      
      getReceivedTransactions: () => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return [];
        
        return get().transactions.filter(
          (tx) => tx.receiverId === currentUser.id && tx.type === 'send'
        ).sort((a, b) => b.timestamp - a.timestamp);
      },
      
      filterTransactions: (type, status) => {
        const currentUser = useAuthStore.getState().currentUser;
        
        if (!currentUser) return [];
        
        return get().transactions.filter((tx) => {
          const isUserTransaction = tx.senderId === currentUser.id || tx.receiverId === currentUser.id;
          const matchesType = type ? tx.type === type : true;
          const matchesStatus = status ? tx.status === status : true;
          
          return isUserTransaction && matchesType && matchesStatus;
        }).sort((a, b) => b.timestamp - a.timestamp);
      },
    }),
    {
      name: 'paynest-transaction-storage',
    }
  )
);