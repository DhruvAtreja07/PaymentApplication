import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  optimizeDeps: {
    exclude: ['lucide-react'],
    force: true, // Force dependency optimization
    esbuildOptions: {
      target: 'esnext'
    }
  },
  server: {
    force: true, // Force the server to restart when needed
    hmr: {
      overlay: true // Enable better error overlays
    }
  },
  build: {
    sourcemap: true,
    rollupOptions: {
      onwarn: (warning, warn) => {
        // Suppress certain warnings
        if (warning.code === 'EMPTY_BUNDLE') return;
        warn(warning);
      }
    }
  },
  esbuild: {
    logLevel: 'info',
    target: 'esnext'
  }
});